/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package propertytycoon;
//package monopolyGame;

public interface Property
{
	void affect(Player p);
	Player getOwner();
	String getSet();
	String getName();
	String getText();
	int getCost();
	void setOwner(Player p);
}
