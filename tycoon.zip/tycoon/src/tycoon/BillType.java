/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tycoon;

/**
 *
 * @author jacob
 */
public class BillType {
    
    public static final int ONE = 1;
	public static final int FIVE = 5;
	public static final int TEN = 10;
	public static final int TWENTY = 20;
	public static final int FIFTY = 50;
	public static final int HUNDRED = 100;
	public static final int FIVE_HUNDRED = 500;
    
}
