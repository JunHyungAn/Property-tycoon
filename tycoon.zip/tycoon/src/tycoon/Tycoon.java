/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tycoon;

import java.util.Properties;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


import com.jtattoo.plaf.graphite.GraphiteLookAndFeel;
/**
 *
 * @author jacob
 */
public class Tycoon {

    /**
     * @param args the command line arguments
     */
    public static void main(final String[] args)
	{
		new Thread()
		{
			@Override
			public void run()
			{
				monopoly.print("GameLauncher -> Setting look and feel for game window...");
				setLookAndFeel();
				// GameBoard.loadTokens = false;
				// Create the game.
				monopoly.print("GameLauncher -> Creating game instance...");
				final monopoly game = new monopoly(true);
				game.start();
				game.getGameWindow().show();
			};
		}.start();

	}
    private static void setLookAndFeel()
	{
		// setup the look and feel properties
		final Properties props = new Properties();

		props.put("logoString", "");
		props.put("licenseKey", "");

		// set your theme
		GraphiteLookAndFeel.setCurrentTheme(props);
		// select the Look and Feel
		try
		{
			UIManager.setLookAndFeel("com.jtattoo.plaf.graphite.GraphiteLookAndFeel");
		} catch (final ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final InstantiationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final IllegalAccessException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final UnsupportedLookAndFeelException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
}
