/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tycoon;

import java.util.ArrayList;


/**
 *
 * @author jacob
 */
public class Bank {
    
    public static final int STARTING_AMOUNT = 20580;
	private int cash;
	private final ArrayList<Bill> bankBills;

	public Bank(final Player[] players)
	{
		monopoly.print("Bank -> Setting up banks starting cash.");
		bankBills = startingBankBills();

		cash = STARTING_AMOUNT;

		monopoly.print("Bank -> Dealing players their starting cash.");

		final ArrayList<Bill> playerBills = startingPlayerBills();
		for (final Player player : players)
		{
			player.setStartingBills(this, playerBills);
		}

	}

	private ArrayList<Bill> startingBankBills()
	{
		final ArrayList<Bill> bills = new ArrayList<Bill>();
		bills.add(new Bill(BillType.ONE, 30));
		bills.add(new Bill(BillType.FIVE, 30));
		bills.add(new Bill(BillType.TEN, 30));
		bills.add(new Bill(BillType.TWENTY, 30));
		bills.add(new Bill(BillType.FIFTY, 30));
		bills.add(new Bill(BillType.HUNDRED, 30));
		bills.add(new Bill(BillType.FIVE_HUNDRED, 30));
		return bills;
	}

	public ArrayList<Bill> startingPlayerBills()
	{
		final ArrayList<Bill> bills = new ArrayList<Bill>();
		bills.add(new Bill(BillType.ONE, 5));
		bills.add(new Bill(BillType.FIVE, 5));
		bills.add(new Bill(BillType.TEN, 5));
		bills.add(new Bill(BillType.TWENTY, 6));
		bills.add(new Bill(BillType.FIFTY, 2));
		bills.add(new Bill(BillType.HUNDRED, 2));
		bills.add(new Bill(BillType.FIVE_HUNDRED, 2));
		return bills;
	}

	public void removeBill(final int type, final int amount)
	{

		for (final Bill bill : bankBills)
		{
			if (bill.getType() == type)
			{
				bill.setAmount(bill.getAmount() - amount);
				// J2DMonopoly.print("Bank -> Removing $" + type * amount + " from bank ($" + type + "x" + amount + ")");
				cash -= type * amount;
			}
		}

	}

	private void printBankBills()
	{
		// J2DMonopoly.print("Bank -> Total cash amount: $" + CashFormatter.format(cash));
		for (final Bill bill : bankBills)
		{
			monopoly.print("Bank -> Contains a (" + bill.getType() + ") bill (x" + bill.getAmount() + ")");
		}
	}

	private void printCash()
	{
		monopoly.print("Bank -> Total cash amount: $" + CashFormatter.format(cash));
	}

	public int getCash()
	{
		return cash;
	}

    
}
