/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package propertytycoon;
//package monopolyGame;
import java.util.Scanner;

public class Card
{
	public Card(String anAction)
	{
		action = anAction;
	}
	
	public String getAction()
	{
		return action;
	}
	
	public void affect(Player p)
	{ if (action.equals("\nBank pays you divided of 50\n")){p.earn(50);};
          if (action.equals("\nyou have won a lip sync battle. Collect 100\n")){p.earn(100);};
          if (action.equals("\nAdvance to Turing Heights\n")){p.setLoc(39);};
          if (action.equals("\nAdvance to Han Xin Gardens.If you pass GO, collect 200\n")){if (p.getLoc()<24){p.setLoc(24);}else{p.setLoc(24);p.earn(200);}};
          if (action.equals("\nFined 15 for speeding\n")){p.pay(15);};
          if (action.equals("\nPay university fees of 150\n")){p.pay(150);};
          if (action.equals("\nTake a trip to Hove Station. If you pass GO collect 200\n")){if (p.getLoc()<15){p.setLoc(15);}else{p.setLoc(15);p.earn(200);}};
          if (action.equals("\nLoan matures,collect 150\n")){p.earn(150);};
          if (action.equals("\nYou are assesed for repairs, 40/house, 115/hotel\n")){};////////////////////TODO
          if (action.equals("\nAdvance to GO\n")){p.setLoc(0);};
          if (action.equals("\nYou are assessed for repairs, 25/house,100/hotel\n")){};/////////////////TODO
          if (action.equals("\nGo back 3 spaces\n")){p.move(-3);};
          if (action.equals("\nAdvance to Skywalker Drive. If you pass GO collect 200\n")){if (p.getLoc()<11){p.setLoc(11);}else{p.setLoc(11);p.earn(200);}};
          if (action.equals("\nGo to jail. Do not pass GO, do not collect 200\n")){p.jail();};
          if (action.equals("\nDrunk in charge of a skateboard. Fine 20\n")){p.pay(20);};
          if (action.equals("\nGet out of jail free\n")){p.giveCard(this);};
	
          if (action.equals("\nYou inherit 100\n")){p.earn(100);};
          if (action.equals("\nYou have won 2nd prize in a beauty contest, collect 200\n")){p.earn(200);};
          if (action.equals("\nGo back to Crapper Street\n")){p.setLoc(1);};
          if (action.equals("\nStudent loan refund. Collect 20\n")){p.earn(20);};
          if (action.equals("\nBank error in your favour. Collect 200\n")){p.earn(200);};
          if (action.equals("\nPay bill for text books of 100\n")){p.pay(100);};
          if (action.equals("\nMega late night taxi bill pay 50\n")){p.pay(50);};
          if (action.equals("\nAdvance to GO\n")){p.setLoc(0);};
          if (action.equals("\nFrom sale of Bitcoin you get 50\n")){p.earn(50);};
          ////////////TODO
          if (action.equals("\nPay a 10 fine or take opportunity knocks\n")){Scanner myObj = new Scanner(System.in); System.out.println("pay fine? yes/no"); String reply = myObj.nextLine();if(reply.equals("yes")){p.pay(50);}else{}};
          if (action.equals("\nPay insurance fee of 50\n")){p.pay(50);};
          if (action.equals("\nSavings bond matures,collect 100\n")){p.earn(100);};
          if (action.equals("\nGo to jail. Do not pass GO, do not collect 200\n")){p.jail();};
          if (action.equals("\nReceived interest on shares of 25\n")){p.earn(25);};
          if (action.equals("\nIts your birthday. Collect 10 from each player\n")){};//////////TODO
          if (action.equals("\nGet out of jail free\n")){p.giveCard(this);};
	}
	
	private String action;
}
