/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package propertytycoon;
//package monopolyGame;

public class CardStack implements Property
{
	private String name;
	private Player banker;
	public CardStack(Card[] aStack)
	{
		stack = aStack;
		topCard = 0;
		banker = new Player();
                boolean potluck=false;
                for(Card c:stack){
                    if(c.getAction().equals("You inherit 100"))
                        {potluck=true;}}
                if(potluck==true){
                    name="Pot Luck";
                }else{
                    name="Opportunity Knocks";}
	}
	
	public void affect(Player p)
	{
		stack[topCard].affect(p);
		topCard = (topCard+1)%stack.length;
	}
	
	public Player getOwner()
	{
		return banker;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getSet()
	{
		return null;
	}
	
	public void setOwner(Player p)
	{
	}
	
	public int getCost()
	{
		return 0;
	}
	
	public String getText()
	{
		return stack[topCard].getAction();
	}
	
	private int topCard;
	private Card[] stack;
}